# Ziv Portfolio Site

Vite + React + Tailwind starter. Deploys instantly on Vercel.

## Local dev
```bash
npm i
npm run dev
```

## Build
```bash
npm run build
```

## Deploy on Vercel
- Push to GitHub
- Import the repo at https://vercel.com/new
- Framework preset: **Vite**
- Build Command: `npm run build`
- Output Directory: `dist`
